import AppShell from '@/components/AppShell';
import DemoPanel from '@/components/DemoPanel';

export default function DemoPage() {
  return (
    <AppShell>
      <div className="space-y-6">
        <div><p className="text-xs font-semibold uppercase tracking-[0.15em] text-blue-600">V2 demonstration</p><h1 className="mt-1 text-3xl font-bold tracking-tight">Memory changes the investigation</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">Compare the same investigation with memory disabled and with real Hindsight memory enabled.</p></div>
        <DemoPanel />
      </div>
    </AppShell>
  );
}
