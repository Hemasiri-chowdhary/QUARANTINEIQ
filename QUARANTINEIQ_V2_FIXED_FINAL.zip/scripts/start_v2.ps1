$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
if (Test-Path "$root\venv\Scripts\Activate.ps1") { & "$root\venv\Scripts\Activate.ps1" }
Write-Host "Starting QuarantineIQ V2 backend on http://127.0.0.1:8001" -ForegroundColor Cyan
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8001 --reload
