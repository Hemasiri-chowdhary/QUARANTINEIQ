import json
import sys
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

BACKEND = "http://127.0.0.1:8001"
HINDSIGHT = "http://127.0.0.1:8888"

def req(url, method="GET", body=None):
    data = json.dumps(body).encode() if body is not None else None
    request = Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    with urlopen(request, timeout=25) as response:
        raw = response.read().decode("utf-8")
        return response.status, json.loads(raw) if raw else {}

def check(name, fn):
    try:
        status, payload = fn()
        print(f"[PASS] {name}")
        return payload
    except Exception as exc:
        print(f"[FAIL] {name}: {exc}")
        return None

failures = 0
if check("Backend health", lambda: req(f"{BACKEND}/health")) is None:
    failures += 1
h = check("Hindsight health", lambda: req(f"{HINDSIGHT}/health"))
if h is None:
    print("       Hindsight check failed; live-memory checks cannot run.")
    failures += 1
status = check("V2 system status", lambda: req(f"{BACKEND}/api/status"))
if status is None or "github" not in status or "hindsight" not in status:
    failures += 1

tests = check("Test inventory", lambda: req(f"{BACKEND}/api/tests"))
if tests is None or len(tests) < 6:
    failures += 1

patterns = check("Pattern endpoint", lambda: req(f"{BACKEND}/api/patterns"))
if patterns is None:
    failures += 1

challenge = check("Decision Challenger capable", lambda: req(f"{BACKEND}/api/decision-challenges"))
if challenge is None:
    failures += 1

live = check("GitHub status endpoint", lambda: req(f"{BACKEND}/api/github/status"))
if live is None or "configured" not in live:
    failures += 1

without = check("Without-memory demo", lambda: req(f"{BACKEND}/api/demo/without-memory", "POST"))
if without is None or without.get("memory_status") != "disabled for demo":
    failures += 1

if h is not None and h.get("status") == "healthy":
    with_memory = check("With-memory demo", lambda: req(f"{BACKEND}/api/demo/with-memory", "POST"))
    if with_memory is None:
        failures += 1
    else:
        compare = check("Memory comparison", lambda: req(f"{BACKEND}/api/demo/compare", "POST"))
        if compare is None:
            failures += 1
        else:
            a = compare["without_memory"]["attention_score"]["score"]
            b = compare["with_memory"]["attention_score"]["score"]
            print(f"       score without memory: {a}")
            print(f"       score with memory:    {b}")
            print(f"       recalled memories:    {len(compare['with_memory'].get('historical_evidence', []))}")
            if b < a:
                failures += 1

if failures:
    print(f"\nV2 verification failed: {failures} check(s).")
    sys.exit(1)
print("\nV2 verification passed.")
