$ErrorActionPreference = "Stop"
if (-not $env:HINDSIGHT_API_LLM_API_KEY) { Write-Error "Set HINDSIGHT_API_LLM_API_KEY first." }
$root = Split-Path -Parent $PSScriptRoot

$env:HINDSIGHT_API_LLM_PROVIDER = "groq"
$env:HINDSIGHT_API_LLM_MODEL = "openai/gpt-oss-20b"
$env:HINDSIGHT_API_LLM_GROQ_SERVICE_TIER = "on_demand"
$env:HINDSIGHT_API_PORT = "8888"

Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$root'; hindsight-api"

Write-Host "Waiting for Hindsight at http://localhost:8888 ..."
$ready = $false
for ($i = 0; $i -lt 36; $i++) {
    Start-Sleep -Seconds 5
    try {
        $health = Invoke-RestMethod "http://localhost:8888/health" -TimeoutSec 3
        if ($health.status -eq "healthy") { $ready = $true; break }
    } catch {}
}

if (-not $ready) { Write-Error "Hindsight did not become healthy within 180 seconds." }

Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$root'; .\venv\Scripts\activate; python scripts\seed_demo.py; uvicorn backend.main:app --port 8001 --reload"
Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$root\frontend'; npm install; npm run dev"

Write-Host "QuarantineIQ V1 services started. Open http://localhost:3000"
