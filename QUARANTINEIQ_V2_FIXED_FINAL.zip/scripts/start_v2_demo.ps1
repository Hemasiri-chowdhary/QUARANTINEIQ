$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
if (Test-Path "$root\venv\Scripts\Activate.ps1") { & "$root\venv\Scripts\Activate.ps1" }
Write-Host "Starting QuarantineIQ V2 in demo mode (backend only)." -ForegroundColor Cyan
python scripts\seed_demo.py
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8001 --reload
