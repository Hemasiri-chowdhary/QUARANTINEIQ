import json
import sys
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

BACKEND = "http://127.0.0.1:8001"
HINDSIGHT = "http://127.0.0.1:8888"


def req(url, method="GET", body=None):
    data = json.dumps(body).encode() if body is not None else None
    request = Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    with urlopen(request, timeout=30) as response:
        raw = response.read().decode()
        return response.status, json.loads(raw) if raw else {}


def check(label, fn):
    try:
        status, payload = fn()
        print(f"[PASS] {label}")
        return payload
    except (HTTPError, URLError, OSError, ValueError, TimeoutError) as exc:
        print(f"[FAIL] {label}: {exc}")
        return None


failures = 0
if check("Backend health", lambda: req(f"{BACKEND}/health")) is None:
    failures += 1
if check("Hindsight health", lambda: req(f"{HINDSIGHT}/health")) is None:
    failures += 1

tests = check("Demo dataset", lambda: req(f"{BACKEND}/api/tests"))
if tests is None or len(tests) < 6:
    failures += 1

status = check("System status", lambda: req(f"{BACKEND}/api/status"))
if status is None or not status.get("hindsight", {}).get("available"):
    failures += 1

without = check("Without-memory investigation", lambda: req(f"{BACKEND}/api/demo/without-memory", "POST"))
if without is None or without.get("historical_evidence"):
    failures += 1

with_memory = check("With-memory investigation", lambda: req(f"{BACKEND}/api/demo/with-memory", "POST"))
if with_memory is None or not with_memory.get("historical_evidence"):
    failures += 1

compare = check("Memory comparison", lambda: req(f"{BACKEND}/api/demo/compare", "POST"))
if compare is not None:
    a = compare["without_memory"]["attention_score"]["score"]
    b = compare["with_memory"]["attention_score"]["score"]
    print(f"       score without memory: {a}")
    print(f"       score with memory:    {b}")
    print(f"       recalled memories:    {len(compare['with_memory']['historical_evidence'])}")
    if b <= a:
        failures += 1
else:
    failures += 1

if failures:
    print(f"\nV1 verification failed: {failures} check(s).")
    sys.exit(1)

print("\nV1 verification passed.")
