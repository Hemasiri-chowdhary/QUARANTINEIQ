# QuarantineIQ V2

QuarantineIQ is a CI decision-intelligence system that combines live or demo CI evidence with persistent engineering memory from Hindsight. V2.0.1 fixes the FastAPI/Hindsight async event-loop integration so memory recall and retention use the SDK async API on the request event loop.

## V2 loop

GitHub Actions → CI ingestion → failure/context → Hindsight memory → attention score → recommendation → Decision Challenger → human decision → outcome → learned memory → future investigation

## What V2 adds

- GitHub repository/workflow synchronization through the GitHub REST API
- Optional `workflow_run` webhook endpoint for near real-time ingestion
- Failed-job log capture when GitHub exposes it
- Commit and changed-file context
- Decision Challenger based on historical regression experiences
- Recurring failure-pattern / potential blind-spot detection
- Cross-test/service semantic memory queries
- Live vs demo source labeling
- V2 dashboard, Memory Explorer, Patterns, and GitHub/CI pages

GitHub's Actions REST API supports listing workflow runs, listing jobs, and downloading job logs; the `workflow_run` event can be used for webhook-driven updates. See the GitHub documentation for these APIs and event semantics. 

## Windows local run

### 1. Hindsight

```powershell
cd C:\path\to\QUARANTINEIQ
.\venv\Scripts\activate
$env:HINDSIGHT_API_LLM_PROVIDER="groq"
$env:HINDSIGHT_API_LLM_API_KEY="YOUR_GROQ_API_KEY"
$env:HINDSIGHT_API_LLM_MODEL="openai/gpt-oss-20b"
$env:HINDSIGHT_API_LLM_GROQ_SERVICE_TIER="on_demand"
hindsight-api
```

### 2. Backend

Open another terminal:

```powershell
cd C:\path\to\QUARANTINEIQ
.\venv\Scripts\activate
python scripts\seed_demo.py
uvicorn backend.main:app --host 127.0.0.1 --port 8001 --reload
```

### 3. Frontend

Open another terminal:

```powershell
cd C:\path\to\QUARANTINEIQ\frontend
npm install
npm run dev
```

Open http://localhost:3000.

## Live GitHub mode

Copy `.env.example` to `.env` and set:

```text
GITHUB_REPOSITORY=owner/repository
GITHUB_TOKEN=your_read_token
GITHUB_WEBHOOK_SECRET=optional-secret
```

Restart the backend, then open **GitHub / CI** and click **Sync GitHub now**. The server reads workflow runs/jobs and available failed-job logs, then stores normalized CI evidence locally.

For webhook mode, configure a GitHub repository webhook to:

```text
https://YOUR_PUBLIC_HOST/api/github/webhook
```

and subscribe to `workflow_run`. A public URL/tunnel is required for GitHub to reach a local Windows machine.

## Verification

With Hindsight and the backend running:

```powershell
python backend\test_hindsight.py
python scripts\verify_v2.py
```

The FastAPI memory endpoints use `aretain`/`arecall` and create the Hindsight client inside the running request event loop. Restart both Hindsight and the QuarantineIQ backend after updating the code before verifying memory again.

Then build the frontend:

```powershell
cd frontend
npm run build
```

## V1 demo fallback

The original demo dataset and the without-memory/with-memory comparison remain available. Run `python scripts\seed_demo.py` whenever you want to reset the local demo database.
