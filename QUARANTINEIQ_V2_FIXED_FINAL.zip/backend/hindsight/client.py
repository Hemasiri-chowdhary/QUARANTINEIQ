import json
import logging
import os
import urllib.error
import urllib.request
import atexit
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
load_dotenv(os.path.join(PROJECT_ROOT, ".env"))

try:
    from hindsight_client import Hindsight
except ImportError:
    Hindsight = None

logger = logging.getLogger(__name__)
HINDSIGHT_URL = os.getenv("HINDSIGHT_URL", "http://localhost:8888").rstrip("/")
HINDSIGHT_API_KEY = os.getenv("HINDSIGHT_API_KEY", "")
HINDSIGHT_BANK_ID = os.getenv("HINDSIGHT_BANK_ID", "quarantineiq-experiences")
_CLIENT = None


class HindsightError(RuntimeError):
    pass


def hindsight_health(timeout: float = 3.0) -> bool:
    try:
        with urllib.request.urlopen(f"{HINDSIGHT_URL}/health", timeout=timeout) as response:
            if response.status != 200:
                return False
            payload = json.loads(response.read().decode("utf-8"))
            return payload.get("status") == "healthy"
    except (OSError, urllib.error.URLError, json.JSONDecodeError):
        return False


def get_hindsight_client():
    global _CLIENT
    if Hindsight is None:
        return None
    if _CLIENT is not None:
        return _CLIENT
    kwargs = {"base_url": HINDSIGHT_URL}
    if HINDSIGHT_API_KEY:
        kwargs["api_key"] = HINDSIGHT_API_KEY
    try:
        _CLIENT = Hindsight(**kwargs)
        return _CLIENT
    except Exception as exc:
        logger.error("Failed to initialize Hindsight client: %s", exc)
        return None


def close_hindsight_client() -> None:
    global _CLIENT
    if _CLIENT is None:
        return
    for name in ("close", "aclose"):
        closer = getattr(_CLIENT, name, None)
        if callable(closer):
            try:
                result = closer()
                if hasattr(result, "__await__"):
                    import asyncio
                    try:
                        asyncio.run(result)
                    except RuntimeError:
                        pass
            except Exception:
                pass
            break
    _CLIENT = None


atexit.register(close_hindsight_client)


async def _new_hindsight_client_async():
    """Create a Hindsight client inside the currently running asyncio loop.

    FastAPI executes ``async def`` endpoints on its application event loop.
    The Hindsight Python SDK uses aiohttp underneath, so the client must be
    created and used on that same loop. A process-global client created from a
    sync/threadpool endpoint can become bound to a different loop and trigger
    ``RuntimeError: Timeout context manager should be used inside a task``.
    """
    if Hindsight is None:
        raise HindsightError("Hindsight client package is unavailable.")
    kwargs = {"base_url": HINDSIGHT_URL}
    if HINDSIGHT_API_KEY:
        kwargs["api_key"] = HINDSIGHT_API_KEY
    try:
        return Hindsight(**kwargs)
    except Exception as exc:
        logger.error("Failed to initialize async Hindsight client: %s", exc)
        raise HindsightError(str(exc)) from exc


async def _close_hindsight_client_async(client: Any) -> None:
    if client is None:
        return
    closer = getattr(client, "aclose", None)
    if callable(closer):
        try:
            await closer()
            return
        except Exception:
            logger.debug("Async Hindsight client close failed", exc_info=True)
    closer = getattr(client, "close", None)
    if callable(closer):
        try:
            result = closer()
            if hasattr(result, "__await__"):
                await result
        except Exception:
            logger.debug("Hindsight client close failed", exc_info=True)


async def async_retain_experience(experience: Dict[str, Any]) -> bool:
    """Retain memory without crossing asyncio event-loop boundaries.

    Hindsight's Python SDK exposes both async and sync convenience APIs. In this
    application, recall uses the async API successfully, but retain can be
    sensitive to the aiohttp loop/session lifecycle on Windows. For the write
    path, run the SDK's synchronous retain wrapper in a worker thread. The
    client and the event loop created by the SDK then live in the same thread,
    which avoids cross-loop aiohttp timeout/session errors.
    """
    if not hindsight_health():
        raise HindsightError(f"Hindsight is unavailable at {HINDSIGHT_URL}.")
    if Hindsight is None:
        raise HindsightError("Hindsight client package is unavailable.")

    content = json.dumps(experience, ensure_ascii=False, default=str)

    def _retain_sync() -> bool:
        kwargs = {"base_url": HINDSIGHT_URL}
        if HINDSIGHT_API_KEY:
            kwargs["api_key"] = HINDSIGHT_API_KEY
        client = Hindsight(**kwargs)
        try:
            client.retain(bank_id=HINDSIGHT_BANK_ID, content=content)
            return True
        except Exception as exc:
            logger.error("Hindsight retain failed in worker thread: %s", exc)
            raise
        finally:
            closer = getattr(client, "close", None)
            if callable(closer):
                try:
                    closer()
                except Exception:
                    logger.debug("Hindsight sync client close failed", exc_info=True)

    try:
        return await __import__("asyncio").to_thread(_retain_sync)
    except Exception as exc:
        raise HindsightError(str(exc)) from exc


async def async_recall_experiences(query: str, limit: int = 5) -> List[Dict[str, Any]]:
    """Recall memories using the SDK's async API on the current event loop."""
    if not hindsight_health():
        raise HindsightError(f"Hindsight is unavailable at {HINDSIGHT_URL}.")
    client = await _new_hindsight_client_async()
    try:
        response = await client.arecall(
            bank_id=HINDSIGHT_BANK_ID,
            query=query,
        )
        results = getattr(response, "results", None)
        if results is None and isinstance(response, list):
            results = response
        if results is None and isinstance(response, dict):
            results = response.get("results", response.get("memories", []))

        output = []
        for result in list(results or [])[:limit]:
            text = _extract_text(result)
            if not text:
                continue
            try:
                parsed = json.loads(text)
                payload = parsed if isinstance(parsed, dict) else {"raw_content": text}
            except (json.JSONDecodeError, TypeError):
                payload = {"raw_content": text}
            score = _extract_score(result)
            if score is not None:
                payload["_score"] = score
            output.append(payload)
        return output[:limit]
    except Exception as exc:
        logger.error("Hindsight async recall failed: %s", exc)
        raise HindsightError(str(exc)) from exc
    finally:
        await _close_hindsight_client_async(client)


def retain_experience(experience: Dict[str, Any]) -> bool:
    client = get_hindsight_client()
    if client is None:
        raise HindsightError("Hindsight client package is unavailable.")
    if not hindsight_health():
        raise HindsightError(f"Hindsight is unavailable at {HINDSIGHT_URL}.")
    try:
        client.retain(
            bank_id=HINDSIGHT_BANK_ID,
            content=json.dumps(experience, ensure_ascii=False, default=str),
        )
        return True
    except Exception as exc:
        logger.error("Hindsight retain failed: %s", exc)
        raise HindsightError(str(exc)) from exc


def _extract_text(result: Any) -> str:
    if isinstance(result, str):
        return result
    if isinstance(result, dict):
        return result.get("text") or result.get("content") or result.get("raw_content") or ""
    return getattr(result, "text", None) or getattr(result, "content", None) or ""


def _extract_score(result: Any):
    value = result.get("score") if isinstance(result, dict) else getattr(result, "score", None)
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def recall_experiences(query: str, limit: int = 5) -> List[Dict[str, Any]]:
    client = get_hindsight_client()
    if client is None:
        raise HindsightError("Hindsight client package is unavailable.")
    if not hindsight_health():
        raise HindsightError(f"Hindsight is unavailable at {HINDSIGHT_URL}.")
    try:
        response = client.recall(bank_id=HINDSIGHT_BANK_ID, query=query)
        results = getattr(response, "results", None)
        if results is None and isinstance(response, list):
            results = response
        if results is None and isinstance(response, dict):
            results = response.get("results", response.get("memories", []))

        output = []
        for result in list(results or [])[:limit]:
            text = _extract_text(result)
            if not text:
                continue
            try:
                parsed = json.loads(text)
                payload = parsed if isinstance(parsed, dict) else {"raw_content": text}
            except (json.JSONDecodeError, TypeError):
                payload = {"raw_content": text}
            score = _extract_score(result)
            if score is not None:
                payload["_score"] = score
            output.append(payload)
        return output[:limit]
    except Exception as exc:
        logger.error("Hindsight recall failed: %s", exc)
        raise HindsightError(str(exc)) from exc
