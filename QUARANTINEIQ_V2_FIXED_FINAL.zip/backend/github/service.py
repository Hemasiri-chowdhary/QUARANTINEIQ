from datetime import datetime, timezone
from typing import Dict, List, Optional

from sqlalchemy.orm import Session

from backend.database import models
from .client import GITHUB_REPOSITORY, GitHubClient, GitHubError, extract_test_names, split_repository


def github_is_configured() -> bool:
    return bool(GITHUB_REPOSITORY)


def _dt(value: Optional[str]) -> datetime:
    if not value:
        return datetime.utcnow()
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        return datetime.utcnow()


def _duration_ms(run: dict, job: dict) -> int:
    start = job.get("started_at") or run.get("run_started_at")
    end = job.get("completed_at") or run.get("updated_at") or run.get("created_at")
    if start and end:
        a = _dt(start)
        b = _dt(end)
        return max(0, int((b - a).total_seconds() * 1000))
    return 0


def _failure_type(job: dict, logs: str) -> str:
    text = f"{job.get('conclusion', '')} {logs}".lower()
    for key, label in (("timeout", "timeout"), ("timed out", "timeout"), ("429", "rate_limit"), ("503", "dependency_503"), ("connection", "connection"), ("assert", "assertion"), ("permission", "authorization"), ("unauthorized", "authorization")):
        if key in text:
            return label
    return "ci_failure" if job.get("conclusion") == "failure" else "unknown"


def _error_message(logs: str) -> Optional[str]:
    lines = [line.strip() for line in (logs or "").splitlines() if line.strip()]
    for line in reversed(lines):
        lower = line.lower()
        if any(token in lower for token in ("error", "failed", "failure", "exception", "timeout")):
            return line[:500]
    return lines[-1][:500] if lines else None


def _upsert_commit(db: Session, client: GitHubClient, repository: str, sha: str, cache: Dict[str, dict]) -> Optional[models.Commit]:
    if not sha:
        return None
    existing = db.query(models.Commit).filter(models.Commit.sha == sha).first()
    if existing:
        return existing
    if sha in cache:
        data = cache[sha]
    else:
        try:
            data = client.get_commit(repository, sha)
            cache[sha] = data
        except GitHubError:
            return None
    message = ((data.get("commit") or {}).get("message") or "").splitlines()[0][:500]
    author = ((data.get("author") or {}).get("login") or ((data.get("commit") or {}).get("author") or {}).get("name") or "unknown")
    files = ",".join(f.get("filename", "") for f in (data.get("files") or [])[:40])
    obj = models.Commit(sha=sha, message=message, files_changed=files, author=author, timestamp=_dt((data.get("commit") or {}).get("author", {}).get("date")), repository=repository, url=data.get("html_url"), source="github")
    db.add(obj)
    db.flush()
    return obj


def github_sync(db: Session, repository: Optional[str] = None) -> dict:
    repository = (repository or GITHUB_REPOSITORY).strip()
    client = GitHubClient()
    if not repository:
        raise GitHubError("No GitHub repository configured. Set GITHUB_REPOSITORY=owner/repo.")
    owner, repo = split_repository(repository)
    # Validate repository and permissions first.
    client.get_repo(repository)
    runs = client.list_workflow_runs(repository, per_page=25)
    sync = db.query(models.RepositorySync).filter(models.RepositorySync.repository == repository).first()
    if not sync:
        sync = models.RepositorySync(repository=repository, source="github")
        db.add(sync)
        db.flush()

    created_tests = created_runs = created_commits = jobs_seen = 0
    errors: List[str] = []
    commit_cache: Dict[str, dict] = {}

    for run in runs:
        run_id = str(run.get("id"))
        try:
            jobs = client.list_jobs(repository, int(run.get("id")))
        except GitHubError as exc:
            errors.append(f"run {run_id}: {exc}")
            continue
        jobs_seen += len(jobs)
        for job in jobs:
            job_id = str(job.get("id"))
            if not job_id:
                continue
            existing_run = db.query(models.CIRun).filter(models.CIRun.job_id == job_id).first()
            if existing_run:
                continue
            logs = ""
            if job.get("conclusion") in {"failure", "cancelled", "timed_out"}:
                try:
                    logs = client.get_job_logs(repository, int(job_id))
                except GitHubError as exc:
                    errors.append(f"job {job_id} logs: {exc}")
            test_names = extract_test_names(logs, job.get("name") or run.get("name") or "ci-job")
            test_name = test_names[0] if test_names else "github_ci_job"
            external_key = f"github:{repository}:{test_name}"
            test = db.query(models.Test).filter(models.Test.external_key == external_key).first()
            if not test:
                test = models.Test(name=test_name, service=f"github/{repo}", repository=repository, status=models.TestStatus.quarantined if job.get("conclusion") == "failure" else models.TestStatus.active, created_at=_dt(run.get("created_at")), source="github", external_key=external_key)
                db.add(test)
                db.flush()
                created_tests += 1
            sha = run.get("head_sha") or job.get("head_sha") or "unknown"
            commit_before = db.query(models.Commit).filter(models.Commit.sha == sha).first() if sha != "unknown" else None
            commit = _upsert_commit(db, client, repository, sha if sha != "unknown" else "", commit_cache)
            if commit and commit_before is None and commit.source == "github":
                created_commits += 1
            status = "passed" if job.get("conclusion") == "success" else "failed" if job.get("conclusion") in {"failure", "timed_out"} else str(job.get("conclusion") or job.get("status") or "unknown")
            run_obj = models.CIRun(
                test_id=test.id,
                commit_sha=sha,
                status=status,
                failure_type=_failure_type(job, logs) if status == "failed" else None,
                error_message=_error_message(logs) if status == "failed" else None,
                duration=_duration_ms(run, job),
                retry_count=0,
                retry_success=False,
                timestamp=_dt(job.get("completed_at") or run.get("updated_at") or run.get("created_at")),
                source="github",
                workflow_run_id=run_id,
                job_id=job_id,
                workflow_name=run.get("name"),
                job_name=job.get("name"),
                log_excerpt=logs[-12000:] if logs else None,
                html_url=run.get("html_url"),
            )
            db.add(run_obj)
            created_runs += 1

    db.commit()
    sync.last_sync_at = datetime.utcnow()
    sync.last_status = "success" if not errors else "partial"
    sync.last_error = " | ".join(errors[:10]) if errors else None
    sync.workflows_seen = len(runs)
    sync.jobs_seen = jobs_seen
    db.commit()
    return {"repository": repository, "status": sync.last_status, "workflows_seen": len(runs), "jobs_seen": jobs_seen, "tests_created": created_tests, "runs_created": created_runs, "commits_created": created_commits, "errors": errors[:20]}
