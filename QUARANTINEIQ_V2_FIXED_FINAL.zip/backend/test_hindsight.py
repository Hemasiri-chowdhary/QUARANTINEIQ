import json
import os
from datetime import datetime, timezone

from dotenv import load_dotenv
from hindsight_client import Hindsight

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
load_dotenv(os.path.join(PROJECT_ROOT, ".env"))

base_url = os.getenv("HINDSIGHT_URL", "http://localhost:8888").rstrip("/")
bank_id = os.getenv("HINDSIGHT_BANK_ID", "quarantineiq-experiences")

client = Hindsight(base_url=base_url)
experience = {
    "experience_id": "verify:quarantineiq:v1",
    "memory_marker": "quarantineiq-v1-verification",
    "test": "test_payment_timeout",
    "service": "payment-service",
    "failure_type": "timeout",
    "evidence": "Payment gateway timeout after 5000ms; retry logic had recently changed.",
    "decision": "investigate",
    "reason": "Repeated timeout failures after a retry change warranted investigation.",
    "human_decision": "quarantine",
    "outcome": "real_regression",
    "lesson": "Timeout failures following retry-logic changes should be investigated before quarantine.",
    "timestamp": datetime.now(timezone.utc).isoformat(),
}

print(f"Hindsight: {base_url}")
print(f"Bank: {bank_id}")
print("Retaining memory...")
client.retain(bank_id=bank_id, content=json.dumps(experience, ensure_ascii=False))
print("RETAIN: SUCCESS")

print("Recalling memory...")
response = client.recall(bank_id=bank_id, query="payment timeout retry logic regression quarantine")
results = getattr(response, "results", []) or []
print(f"RECALL RESULTS: {len(results)}")
for index, result in enumerate(results[:5], 1):
    print(f"[{index}] {getattr(result, 'text', result)}")

if not results:
    raise SystemExit("RECALL: FAILED — no memory returned")
print("RECALL: SUCCESS")
